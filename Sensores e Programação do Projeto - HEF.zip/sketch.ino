#include <SPI.h>
#include <MFRC522.h>

#define SS_PIN 10
#define RST_PIN 9

MFRC522 rfid(SS_PIN, RST_PIN);

void setup() {
  Serial.begin(9600);

  SPI.begin();
  rfid.PCD_Init();

  Serial.println("================================");
  Serial.println("     LEITOR RFID INICIADO");
  Serial.println("================================");
  Serial.println("Aproxime uma tag RFID...");
}

void loop() {

  // Verifica se existe uma nova tag
  if (!rfid.PICC_IsNewCardPresent()) {
    return;
  }

  // Tenta ler a tag
  if (!rfid.PICC_ReadCardSerial()) {
    return;
  }

  Serial.println("TAG ENCONTRADA!");

  Serial.print("UID: ");

  for (byte i = 0; i < rfid.uid.size; i++) {

    if (rfid.uid.uidByte[i] < 0x10) {
      Serial.print("0");
    }

    Serial.print(rfid.uid.uidByte[i], HEX);

    if (i < rfid.uid.size - 1) {
      Serial.print(" ");
    }
  }

  Serial.println();
  Serial.println("------------------------------");

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  delay(1000);
}